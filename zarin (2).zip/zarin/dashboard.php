<?php
session_start();
require_once './database/db.php';
require_once 'jdf.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :user_id AND is_deleted = 0");
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: index.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM salary_slips WHERE user_id = :user_id ORDER BY year DESC, month DESC");
$stmt->execute(['user_id' => $user_id]);
$salary_slips = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>داشبورد کاربری</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.fontcdn.ir/Font/Persian/IranSans/IranSans.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'IranSans', sans-serif !important;
            background-color: #f4f7fa;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 17px;
            display: block;
        }

        .sidebar a:hover {
            background-color: #007bff;
        }

        .content {
            padding: 30px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: #007bff;
        }

        .table th,
        .table td {
            text-align: center;
            vertical-align: middle;
        }

        .btn-outline-primary {
            border: 1px solid #007bff;
            color: #007bff;
        }

        .btn-outline-primary:hover {
            background-color: #007bff;
            color: white;
        }

        .text-muted {
            font-size: 15px;
        }

        h2 {
            color: #343a40;
            font-weight: bold;
        }

        @media (min-width: 768px) {
            .dashboard-container {
                display: flex;
            }

            .sidebar {
                width: 250px;
                height: 100vh;
                position: fixed;
                right: 0;
                top: 0;
            }

            .content {
                margin-right: 260px;
            }
        }
    </style>
</head>
<body>

<div class="dashboard-container">
<?php require_once 'sidebar.php'; ?>


    <!-- Content -->
    <div class="content container-fluid">
        <h2 class="mb-4">خوش آمدید <?= htmlspecialchars($user['name']) ?> عزیز</h2>

        <div class="row">
            <!-- User Info -->
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fa fa-user"></i> اطلاعات حساب کاربری</h5>
                        <p><strong>نام:</strong> <?= htmlspecialchars($user['name']) ?></p>
                        <p><strong> کد ملی:</strong> <?= htmlspecialchars($user['national_code']) ?></p>
                        <p><strong>  شماره تلفن:</strong> <?= htmlspecialchars($user['phone']) ?></p>
                        <p><strong>تاریخ عضویت:</strong> <?= jdate('Y/m/d', strtotime($user['created_at'])) ?></p>
                    </div>
                </div>
            </div>

            <!-- Salary Slips -->
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fa fa-file-alt"></i> فیش‌های حقوقی</h5>

                        <?php if (count($salary_slips)): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered mt-3">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ماه</th>
                                            <th>سال</th>
                                            <th>دانلود</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($salary_slips as $slip): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($slip['month']) ?></td>
                                                <td><?= htmlspecialchars($slip['year']) ?></td>
                                                <td>
                                                    <a href="download_salary.php?id=<?= $slip['id'] ?>" class="btn btn-outline-primary btn-sm">
                                                        <i class="fa fa-download"></i> دانلود
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">فیش حقوقی‌ای ثبت نشده است.</p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>