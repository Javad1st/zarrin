<?php
session_start();
$errors = $_SESSION['login_errors'] ?? [];
$old_phone = $_SESSION['old_phone'] ?? '';
unset($_SESSION['login_errors'], $_SESSION['old_phone']);
?>
<!DOCTYPE html>
<html lang="fa">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>صفحه ورود</title>
  <link rel="stylesheet" href="style.css">
  <style>
   

    .global-alert {
      position: absolute;
      top: 20px;
      right: 50%;
      transform: translateX(50%);
      width: 90%;
      max-width: 420px;
      background-color: #ffeaea;
      border: 1px solid #ff4d4d;
      color: #a50000;
      padding: 15px 20px;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 500;
      line-height: 1.8;
      box-shadow: 0 0 8px rgba(255, 0, 0, 0.1);
      z-index: 999;
      direction: rtl;
      text-align: right;
    }

    .global-alert ul {
      margin: 0;
      padding: 0;
      list-style: none;
    }

    .global-alert li::before {
      content: "⚠️ ";
      margin-left: 6px;
    }

    .login-container {
      background-color: white;
      width: 90%;
      max-width: 420px;
      margin: 120px auto 0;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      direction: rtl;
    }

    h2 {
      margin-bottom: 20px;
      text-align: center;
      color: #333;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
      color: #444;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 14px;
    }

    .error {
      color: red;
      font-size: 13px;
      margin-top: 5px;
    }

    button[type="submit"] {
      width: 100%;
      padding: 12px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button[type="submit"]:hover {
      background-color: #0056b3;
    }
 

  </style>
  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php if (!empty($errors)): ?>
  <div class="global-alert">
    <ul>
      <?php foreach ($errors as $error): ?>
        <li><?= htmlspecialchars($error) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="login-container">
  <h2>ورود به سیستم</h2>
  <form id="loginForm" action="auth.php" method="POST" onsubmit="return validateForm()">
    <div class="form-group">
      <label for="mobile">کد ملی (نام کاربری)</label>
      <input type="text" id="mobile" name="phone" value="<?= htmlspecialchars($old_phone) ?>" placeholder="مثلاً 0012345678">
      <div class="error" id="mobileError"></div>
    </div>
    <div class="form-group">
      <label for="password">رمز عبور</label>
      <input type="password" id="password" name="password" placeholder="رمز عبور را وارد کنید">
      <div class="error" id="passwordError"></div>
    </div>
    <button type="submit">ورود</button>
  </form>
</div>

<script src="script.js"></script>
</body>
</html>
