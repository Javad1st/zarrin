<?php
session_start();

// حذف تمام داده‌های جلسه
session_unset();

// تخریب جلسه
session_destroy();

// هدایت به صفحه ورود
header("Location: index.php");
exit;
