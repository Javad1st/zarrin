<?php
session_start();
require_once './database/db.php';

if (!isset($_SESSION['user_id'])) {
    die("دسترسی غیرمجاز");
}

$user_id = $_SESSION['user_id'];
$id = $_GET['id'] ?? 0;

// دریافت مسیر فایل فقط از دیتابیس
$stmt = $conn->prepare("SELECT file_path FROM salary_slips WHERE id = :id AND user_id = :user_id");
$stmt->execute(['id' => $id, 'user_id' => $user_id]);
$slip = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$slip) {
    die("فیش یافت نشد.");
}

// مسیر پوشه مجاز
$uploadDir = realpath(__DIR__ . '/uploads/salary_slips');
$filePath = realpath($slip['file_path']);

// بررسی امنیتی: فایل باید داخل همین مسیر باشه
if (strpos($filePath, $uploadDir) !== 0 || !file_exists($filePath)) {
    die("فایل معتبر نیست یا مجاز نیستید.");
}

// ارسال فایل
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
readfile($filePath);
exit;
