<?php
require_once './database/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user = $_SESSION['user_id'];

// بررسی ارسال فرم
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $from_shamsi = $_POST['from_shamsi']; // تاریخ شمسی
    $to_shamsi = $_POST['to_shamsi'];     // تاریخ شمسی
    $time_from = $_POST['time_from'];     // ساعت دستی
    $time_to = $_POST['time_to'];         // ساعت دستی
    $reason = $_POST['reason'];           // دلیل مرخصی

    // بررسی تاریخ‌ها
    if (empty($from_shamsi) || empty($to_shamsi)) {
        $_SESSION['message'] = "تاریخ‌ها نمی‌توانند خالی باشند.";
    } else {
        // وارد کردن اطلاعات به پایگاه داده
        $stmt = $conn->prepare("INSERT INTO leave_requests (user_id, date_from, date_to, time_from, time_to, reason) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user, $from_shamsi, $to_shamsi, $time_from, $time_to, $reason]);

        // پیغام موفقیت
        $_SESSION['message'] = "درخواست مرخصی با موفقیت ثبت شد.";
    }

    // هدایت مجدد به صفحه
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>درخواست مرخصی</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css" />
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-control {
            text-align: center;
        }
        .content {
            margin-right: 260px;
        }
        .leave-form-wrapper {
            max-width: 600px;
            margin: 0 auto;
        }
        @media (max-width: 991px) {
            .content {
                margin-right: 0;
                padding: 20px;
            }
        }
        html, body {
            overflow-x: hidden;
        }
    </style>
</head>
<body>
<?php require_once 'sidebar.php'; ?>

<div class="container py-5 content">
    <div class="leave-form-wrapper">
        <h3 class="mb-2">فرم درخواست مرخصی</h3>
        <p class="text-muted mb-4">تاریخ امروز (شمسی): <span id="today-shamsi"></span></p>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success"><?= $_SESSION['message']; ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form method="POST" class="card p-4 shadow-sm bg-white">
            <div class="mb-3">
                <label class="form-label">از تاریخ:</label>
                <input type="text" name="from_shamsi" id="fromDate" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">تا تاریخ:</label>
                <input type="text" name="to_shamsi" id="toDate" class="form-control" required>
            </div>

            <div class="mb-3 d-flex justify-content-between">
                <div class="w-50 pe-2">
                    <label class="form-label">از ساعت:</label>
                    <input type="text" id="time_from" name="time_from" class="form-control" required placeholder="مثلاً 14:30">
                </div>
                <div class="w-50 ps-2">
                    <label class="form-label">تا ساعت:</label>
                    <input type="text" id="time_to" name="time_to" class="form-control" required placeholder="مثلاً 18:00">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">دلیل مرخصی:</label>
                <textarea name="reason" class="form-control" rows="4" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">ارسال درخواست</button>
        </form>

        <?php if (isset($from_shamsi) && isset($to_shamsi) && isset($time_from) && isset($time_to) && isset($reason)): ?>
            <div class="alert alert-info mt-4">
                <h4 class="alert-heading">جزئیات درخواست شما</h4>
                <p><strong>از تاریخ:</strong> <?= $from_shamsi ?></p>
                <p><strong>تا تاریخ:</strong> <?= $to_shamsi ?></p>
                <p><strong>از ساعت:</strong> <?= $time_from ?></p>
                <p><strong>تا ساعت:</strong> <?= $time_to ?></p>
                <p><strong>دلیل مرخصی:</strong> <?= $reason ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>

<script>
    $(document).ready(function () {
        // نمایش تاریخ امروز شمسی
        let today = new persianDate().format("YYYY/MM/DD");
        $("#today-shamsi").text(today);

        // تاریخ شمسی برای انتخاب تاریخ
        $("#fromDate").persianDatepicker({
            format: "YYYY/MM/DD",
            autoClose: true
        });

        $("#toDate").persianDatepicker({
            format: "YYYY/MM/DD",
            autoClose: true
        });
    });
</script>
</body>
</html>
