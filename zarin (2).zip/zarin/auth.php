<?php
session_start();
require_once './database/db.php';

// جلوگیری از دسترسی مستقیم با GET
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    echo "دسترسی غیرمجاز.";
    exit;
}

// تابع پاکسازی ورودی‌ها
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// دریافت و پاکسازی داده‌ها
$national_code = sanitize($_POST['phone'] ?? '');
$password = sanitize($_POST['password'] ?? '');

$errors = [];

// اعتبارسنجی کد ملی
if (!preg_match('/^\d{10}$/', $national_code)) {
    $errors[] = "کد ملی باید ۱۰ رقم عددی باشد.";
}

// اعتبارسنجی رمز عبور
if (strlen($password) < 4) {
    $errors[] = "رمز عبور باید حداقل ۴ کاراکتر باشد.";
}

// اگر خطایی وجود داشت، برگرد به صفحه ورود
if (!empty($errors)) {
    $_SESSION['login_errors'] = $errors;
    $_SESSION['old_phone'] = $national_code;
    header("Location: index.php");
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE national_code = :national_code AND is_deleted = 0 LIMIT 1");
    $stmt->bindValue(':national_code', $national_code, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'] ?? 'کاربر';
        header("Location: dashboard.php");
        exit;
    } else {
        $_SESSION['login_errors'] = ["کد ملی یا رمز عبور اشتباه است."];
        $_SESSION['old_phone'] = $national_code;
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    error_log("خطای ورود: " . $e->getMessage());
    $_SESSION['login_errors'] = ["خطایی در سیستم رخ داده است. لطفاً بعداً تلاش کنید."];
    header("Location: index.php");
    exit;
}
