<?php
require_once '../database/db.php';
session_start();

// اگر کاربر وارد نشده باشد، به صفحه ورود هدایت می‌شود
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

// نمایش همه درخواست‌های مرخصی و نام کاربر
$query = "SELECT leave_requests.*, users.name AS user_name FROM leave_requests 
          JOIN users ON leave_requests.user_id = users.id";
$stmt = $conn->prepare($query);
$stmt->execute();
$requests = $stmt->fetchAll();

// تایید درخواست
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $update_query = "UPDATE leave_requests SET status = 'approved' WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->execute([$id]);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// رد درخواست
if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    $update_query = "UPDATE leave_requests SET status = 'rejected' WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->execute([$id]);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پنل مدیریت درخواست‌های مرخصی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
        }
        .container {
            width: 90%;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-right: 270px;
        }
        .table td, .table th {
            text-align: center;
        }
        .operation-icons a {
            margin-left: 10px;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo i {
            font-size: 50px;
            color: #007bff;
        }
        .table-container {
            width: 100%;
            overflow-x: hidden;
        }
        .badge-approved {
            background-color: #28a745;
            color: white;
        }
        .badge-rejected {
            background-color: #dc3545;
            color: white;
        }
        .badge-pending {
            background-color: #ffc107;
            color: white;
        }
        .btn-custom {
            font-size: 14px;
            padding: 6px 12px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<?php require_once 'sidebar.php'; ?>

<div class="container py-5">
    <div class="logo">
        <i class="fas fa-calendar-check"></i>
    </div>

    <h3 class="text-center mb-4">پنل مدیریت درخواست‌های مرخصی</h3>

    <div class="mt-4">
        <h5 class="text-center">تمامی درخواست‌های مرخصی</h5>
        <div class="table-container">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>نام کاربر</th>
                        <th>تاریخ از</th>
                        <th>تاریخ تا</th>
                        <th>ساعت از</th>
                        <th>ساعت تا</th>
                        <th>دلیل مرخصی</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($requests) > 0): ?>
                        <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><?= htmlspecialchars($request['user_name']) ?></td>
                                <td><?= htmlspecialchars($request['date_from']) ?></td>
                                <td><?= htmlspecialchars($request['date_to']) ?></td>
                                <td><?= htmlspecialchars($request['time_from']) ?></td>
                                <td><?= htmlspecialchars($request['time_to']) ?></td>
                                <td><?= htmlspecialchars($request['reason']) ?></td>
                                <td>
                                    <?php
                                    switch ($request['status']) {
                                        case 'approved':
                                            echo "<span class='badge badge-approved'>تایید شده</span>";
                                            break;
                                        case 'rejected':
                                            echo "<span class='badge badge-rejected'>رد شده</span>";
                                            break;
                                        case 'pending':
                                            echo "<span class='badge badge-pending'>در انتظار</span>";
                                            break;
                                        default:
                                            echo "<span class='text-muted'>وضعیت نامشخص</span>";
                                    }
                                    ?>
                                </td>
                                <td class="operation-icons">
                                    <?php if ($request['status'] == NULL || $request['status'] == 'pending'): ?>
                                        <a href="?approve=<?= $request['id'] ?>" class="btn btn-success btn-custom"><i class="fas fa-check"></i> تایید</a>
                                        <a href="?reject=<?= $request['id'] ?>" class="btn btn-danger btn-custom"><i class="fas fa-times"></i> رد</a>
                                    <?php else: ?>
                                        <span class="text-muted">عملیات انجام شده</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8">هیچ درخواست مرخصی‌ای موجود نیست.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
