<?php
session_start();
require_once 'jdf.php';
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: manage_salary_slips.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM salary_slips WHERE id = :id");
$stmt->execute(['id' => $id]);
$slip = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$slip) {
    header("Location: manage_salary_slips.php");
    exit;
}

$alert = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $month = $_POST['month'];
    $year = $_POST['year'];

    if (isset($_FILES['salary_file']) && $_FILES['salary_file']['error'] == 0) {
        $file = $_FILES['salary_file'];
        $allowedExtensions = ['pdf', 'xls', 'xlsx'];
        $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);

        if (in_array(strtolower($fileExtension), $allowedExtensions)) {
            $uploadDir = '../uploads/salary_slips/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $fileName = uniqid('salary_') . '.' . $fileExtension;
            $filePath = $uploadDir . $fileName;

            if (move_uploaded_file($file['tmp_name'], $filePath)) {
                $stmt = $conn->prepare("UPDATE salary_slips SET user_id = :user_id, month = :month, year = :year, file_path = :file_path WHERE id = :id");
                $stmt->execute([
                    'user_id' => $user_id,
                    'month' => $month,
                    'year' => $year,
                    'file_path' => $filePath,
                    'id' => $id
                ]);
                $alert = "<div class='alert alert-success'>✅ فیش حقوقی با موفقیت ویرایش شد.</div>";
            } else {
                $alert = "<div class='alert alert-danger'>❌ خطا در آپلود فایل.</div>";
            }
        } else {
            $alert = "<div class='alert alert-warning'>⚠️ فایل باید PDF یا Excel باشد.</div>";
        }
    } else {
        $stmt = $conn->prepare("UPDATE salary_slips SET user_id = :user_id, month = :month, year = :year WHERE id = :id");
        $stmt->execute([
            'user_id' => $user_id,
            'month' => $month,
            'year' => $year,
            'id' => $id
        ]);
        $alert = "<div class='alert alert-success'>✅ فیش حقوقی با موفقیت ویرایش شد.</div>";
    }

    // بروزرسانی اطلاعات فیش در متغیر slip
    $slip['user_id'] = $user_id;
    $slip['month'] = $month;
    $slip['year'] = $year;
}

// لیست کاربران
$stmt = $conn->prepare("SELECT id, name FROM users WHERE is_deleted = 0");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
$user_names = [];
foreach ($users as $u) {
    $user_names[$u['id']] = $u['name'];
}

// لیست ماه‌ها
$months = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ویرایش فیش حقوقی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">

    <h3 class="mb-4">✏️ ویرایش فیش حقوقی</h3>
    <?= $alert ?>

    <form method="POST" class="border p-4 rounded shadow-sm" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">انتخاب کاربر:</label>
            <select name="user_id" class="form-select" required>
                <option value="">انتخاب کاربر</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id'] ?>" <?= $slip['user_id'] == $user['id'] ? 'selected' : '' ?>><?= htmlspecialchars($user['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">ماه:</label>
            <select name="month" class="form-select" required>
                <?php foreach ($months as $m): ?>
                    <option value="<?= $m ?>" <?= $slip['month'] == $m ? 'selected' : '' ?>><?= $m ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">سال:</label>
            <input type="number" name="year" class="form-control" value="<?= $slip['year'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">آپلود فیش حقوقی (PDF یا Excel):</label>
            <input type="file" name="salary_file" class="form-control" accept=".pdf, .xls, .xlsx">
            <small>اگر می‌خواهید فیش حقوقی جدیدی آپلود کنید، فایل را انتخاب کنید.</small>
        </div>

        <button type="submit" class="btn btn-primary">💾 ذخیره تغییرات</button>
        <a href="manage_salary_slips.php" class="btn btn-secondary">بازگشت</a>
    </form>
</div>
</body>
</html>
