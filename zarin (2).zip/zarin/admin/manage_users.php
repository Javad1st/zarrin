<?php
session_start();
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$message = '';
$error = '';

// حذف کاربر اگر پارامتر delete_id ارسال شده باشد
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];

    $stmt_check = $conn->prepare("SELECT COUNT(*) FROM users WHERE id = :id AND is_deleted = 0");
    $stmt_check->execute([':id' => $delete_id]);
    $exists = $stmt_check->fetchColumn();

    if ($exists) {
        $stmt = $conn->prepare("UPDATE users SET is_deleted = 1 WHERE id = :id");
        if ($stmt->execute([':id' => $delete_id])) {
            $message = "✅ کاربر با موفقیت حذف شد.";
        } else {
            $error = "❌ خطا در حذف کاربر. لطفاً دوباره تلاش کنید.";
        }
    } else {
        $error = "کاربری با این شناسه یافت نشد یا قبلاً حذف شده است.";
    }
}

// گرفتن لیست کاربران غیر حذف شده
$stmt = $conn->prepare("SELECT * FROM users WHERE is_deleted = 0");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت کاربران</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/vazirmatn-webfont@1.0.0/dist/font-face.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Vazirmatn', sans-serif;
            display: flex;
            min-height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 270px;
            background-color: #1e293b;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 30px 20px;
            color: white;
        }

        .main-content {
            margin-left: 270px;
            padding: 20px;
            width: calc(100% - 270px);
            display: flex;
            justify-content: center;
        }

        .container {
            margin-top: 50px;
            width: 100%;
            max-width: 1200px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .action-icons i {
            font-size: 18px;
            margin: 0 5px;
        }

        .action-icons i:hover {
            color: #0d6efd;
            cursor: pointer;
        }
    </style>
</head>
<body>

<?php require_once 'sidebar.php'; ?>

<div class="main-content">
    <div class="container">
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="mb-0"><i class="fas fa-users-cog me-2"></i>مدیریت کاربران</h3>
                <a href="add_user.php" class="btn btn-success"><i class="fas fa-user-plus me-1"></i>افزودن کاربر جدید</a>
            </div>

            <!-- نمایش پیام موفقیت یا خطا -->
            <?php if ($message): ?>
                <div class="alert alert-success text-center"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger text-center"><?php echo $error; ?></div>
            <?php endif; ?>

            <table class="table table-striped table-bordered text-center">
                <thead class="table-dark">
                    <tr>
                        <th>ردیف</th>
                        <th>نام</th>
                        <th>کد ملی</th>
                        <th>شماره موبایل</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($users) > 0): ?>
                        <?php foreach ($users as $index => $user): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['national_code']); ?></td>
                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                <td class="action-icons">
                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" title="ویرایش">
                                        <i class="fas fa-edit text-warning"></i>
                                    </a>
                                    <a href="?delete_id=<?php echo $user['id']; ?>" title="حذف" onclick="return confirm('آیا مطمئن هستید؟');">
                                        <i class="fas fa-trash-alt text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">هیچ کاربری یافت نشد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
