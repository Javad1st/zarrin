<?php
session_start();
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id AND is_deleted = 0");
$stmt->execute(['id' => $id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "کاربر یافت نشد.";
    exit;
}

$successMessage = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $national_code = $_POST['national_code'];
    $is_admin = $_POST['is_admin'];
    $password = $_POST['password'];

    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET name = :name, phone = :phone, national_code = :national_code, is_admin = :is_admin, password = :password WHERE id = :id");
        $stmt->execute([
            'name' => $name,
            'phone' => $phone,
            'national_code' => $national_code,
            'is_admin' => $is_admin,
            'password' => $hashedPassword,
            'id' => $id
        ]);
    } else {
        $stmt = $conn->prepare("UPDATE users SET name = :name, phone = :phone, national_code = :national_code, is_admin = :is_admin WHERE id = :id");
        $stmt->execute([
            'name' => $name,
            'phone' => $phone,
            'national_code' => $national_code,
            'is_admin' => $is_admin,
            'id' => $id
        ]);
    }

    $successMessage = "<div class='alert alert-success'>اطلاعات کاربر به‌روزرسانی شد.</div>";
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ویرایش کاربر</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f1f1f1;
            font-family: 'Vazirmatn', sans-serif;
        }
        .container {
            margin-top: 50px;
            max-width: 600px;
        }
        .card {
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<div class="container">
<?php require_once 'sidebar.php'; ?>

    <div class="card bg-white">
        <h3 class="mb-4">ویرایش اطلاعات کاربر</h3>
        <?php echo $successMessage; ?>
        <form action="edit_user.php?id=<?php echo $id; ?>" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">نام:</label>
                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="phone" class="form-label">شماره تلفن:</label>
                <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="national_code" class="form-label">کد ملی:</label>
                <input type="text" class="form-control" name="national_code" value="<?php echo htmlspecialchars($user['national_code']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">رمز عبور (در صورت نیاز به تغییر):</label>
                <input type="password" class="form-control" name="password" placeholder="برای تغییر رمز جدید وارد کنید">
            </div>

            <div class="mb-3">
                <label for="is_admin" class="form-label">نقش کاربر:</label>
                <select name="is_admin" class="form-select">
                    <option value="1" <?php if ($user['is_admin'] == 1) echo 'selected'; ?>>ادمین</option>
                    <option value="0" <?php if ($user['is_admin'] == 0) echo 'selected'; ?>>کاربر معمولی</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">بروزرسانی</button>
        </form>
    </div>
</div>

</body>
</html>
