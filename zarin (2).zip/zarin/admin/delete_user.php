<?php
session_start();
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$id = $_GET['id'];
$stmt = $conn->prepare("UPDATE users SET is_deleted = 1 WHERE id = :id");
$stmt->execute(['id' => $id]);

echo "کاربر حذف شد.";
?>
