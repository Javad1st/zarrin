<?php
session_start();
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if (isset($_GET['file']) && !empty($_GET['file'])) {
    // امن‌سازی ورودی
    $file = basename($_GET['file']);
    $uploadDir = '../uploads/salary_slips/';
    $filePath = $uploadDir . $file;

    if (file_exists($filePath)) {
        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        $contentType = 'application/octet-stream';

        switch ($fileExtension) {
            case 'pdf':
                $contentType = 'application/pdf';
                break;
            case 'xls':
                $contentType = 'application/vnd.ms-excel';
                break;
            case 'xlsx':
                $contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                break;
        }

        header('Content-Type: ' . $contentType);
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    } else {
        showError("❌ فایل مورد نظر پیدا نشد.");
    }
} else {
    showError("⚠️ درخواست دانلود فایل معتبر نیست.");
}

function showError($message)
{
    echo "
    <!DOCTYPE html>
    <html lang='fa' dir='rtl'>
    <head>
        <meta charset='UTF-8'>
        <title>خطا در دانلود فایل</title>
        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css' rel='stylesheet'>
    </head>
    <body class='bg-light'>
        <div class='container mt-5'>
            <div class='alert alert-danger text-center'>
                $message
            </div>
            <div class='text-center mt-3'>
                <a href='manage_salary_slips.php' class='btn btn-primary'>بازگشت</a>
            </div>
        </div>
    </body>
    </html>
    ";
    exit;
}
