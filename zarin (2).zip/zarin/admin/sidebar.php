<!-- sidebar.php -->
<div class="sidebar">
    <div class="profile">
        <i class="fas fa-user-circle"></i>
        <h5>admin</h5>
    </div>

    <a href="admin_dashboard.php"><i class="fas fa-home"></i>صفحه اصلی</a>
    <a href="manage_users.php"><i class="fas fa-users me-2"></i>مدیریت کاربران</a>
    <a href="manage_salary_slips.php"><i class="fas fa-file-invoice-dollar me-2"></i>مدیریت فیش حقوقی‌ها</a>
    <a href="leave.php"><i class="fas fa-clock"></i>    مدیریت مرخصی </a>
    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>خروج</a>
</div>

<style>
   body {
    display: flex;
    min-height: 100vh;
    margin: 0;
    padding: 0;
}

.sidebar {
    width: 270px;
    height: 100vh;
    background-color: #1e293b;
    position: fixed;
    right: 0;
    top: 0;
    color: white;
    padding: 30px 20px;
    z-index: 1000; /* قرار دادن سایدبار بالاتر از محتوا */
}

.sidebar .profile {
    text-align: center;
    margin-bottom: 40px;
}

.sidebar .profile i {
    font-size: 60px;
    margin-bottom: 10px;
    color: #60a5fa;
}

.sidebar .profile h5 {
    margin: 0;
}

.sidebar a {
    display: block;
    color: white;
    padding: 12px 15px;
    margin-bottom: 10px;
    background-color: transparent;
    text-decoration: none;
    border-radius: 8px;
    transition: background-color 0.3s;
}

.sidebar a:hover {
    background-color: #334155;
}

.sidebar a i {
    margin-left: 10px;
}

.main-content {
    margin-right: 270px; /* فاصله از سایدبار */
    width: 100%;
    padding: 20px;
}

.container {
    margin-top: 50px;
}

</style>
