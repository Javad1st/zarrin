<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Tahoma', sans-serif;
            background-color: #f9fafb;
        }
        .sidebar {
            width: 270px;
            height: 100vh;
            background-color: #1e293b;
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            padding: 30px 20px;
        }
        .sidebar .profile {
            text-align: center;
            margin-bottom: 40px;
        }
        .sidebar .profile i {
            font-size: 60px;
            margin-bottom: 10px;
            color: #60a5fa;
        }
        .sidebar .profile h5 {
            margin: 0;
        }
        .sidebar .profile small {
            color: #cbd5e1;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 12px 15px;
            margin-bottom: 10px;
            background-color: transparent;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background-color: #334155;
        }

        .main-content {
            margin-right: 270px;
            padding: 40px;
        }

        .card-box {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.06);
            padding: 30px;
            margin-bottom: 30px;
        }

        .card-box h2 {
            font-size: 28px;
            color: #1f2937;
            margin-bottom: 20px;
        }

        .action-btn {
            display: inline-block;
            background-color: #3b82f6;
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            margin: 10px;
            text-decoration: none;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .action-btn:hover {
            background-color: #2563eb;
        }
    </style>
</head>
<body>

<?php require_once 'sidebar.php'; ?>


<!-- Main Content -->
<div class="main-content">
    <div class="card-box text-center">
        <h2>سلام admin👋</h2>
        <p>به پنل مدیریت خوش آمدید. از اینجا می‌توانید بخش‌های مختلف سیستم را مدیریت کنید.</p>

        <a href="manage_users.php" class="action-btn"><i class="fas fa-users me-1"></i>مدیریت کاربران</a>
        <a href="manage_salary_slips.php" class="action-btn"><i class="fas fa-file-invoice me-1"></i>مدیریت فیش‌ها</a>
        <a href="logout.php" class="action-btn bg-danger"><i class="fas fa-power-off me-1"></i>خروج</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
