<?php
session_start();
require_once 'jdf.php';
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$alert = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $month = $_POST['month'];
    $year = $_POST['year'];

    if (isset($_FILES['salary_file']) && $_FILES['salary_file']['error'] == 0) {
        $file = $_FILES['salary_file'];
        $allowedExtensions = ['pdf', 'xls', 'xlsx'];
        $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);

        if (in_array(strtolower($fileExtension), $allowedExtensions)) {
            $uploadDir = '../uploads/salary_slips/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $fileName = uniqid('salary_') . '.' . $fileExtension;
            $relativePath = 'uploads/salary_slips/' . $fileName; // برای دیتابیس
            $filePath = '../' . $relativePath; // مسیر واقعی

            if (move_uploaded_file($file['tmp_name'], $filePath)) {
                // ذخیره در دیتابیس
                $stmt = $conn->prepare("INSERT INTO salary_slips (user_id, month, year, file_path) VALUES (:user_id, :month, :year, :file_path)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'month' => $month,
                    'year' => $year,
                    'file_path' => $relativePath
                ]);

                header("Location: manage_salary_slips.php?status=success");
                exit;
            } else {
                $alert = "<div class='alert alert-danger'>❌ خطا در آپلود فایل.</div>";
            }
        } else {
            $alert = "<div class='alert alert-warning'>⚠️ فایل باید PDF یا Excel باشد.</div>";
        }
    }
}

// لیست کاربران
$stmt = $conn->prepare("SELECT id, name FROM users WHERE is_deleted = 0");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
$user_names = [];
foreach ($users as $u) {
    $user_names[$u['id']] = $u['name'];
}

// دریافت فیش‌ها
$stmt = $conn->prepare("SELECT * FROM salary_slips ORDER BY year DESC, month DESC");
$stmt->execute();
$salary_slips = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت فیش حقوقی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4">مدیریت فیش حقوقی‌ها</h2>

    <?php
    if (isset($_GET['status']) && $_GET['status'] == 'success') {
        echo "<div class='alert alert-success'>✅ فیش حقوقی با موفقیت آپلود شد.</div>";
    }
    echo $alert;
    ?>

    <form action="manage_salary_slips.php" method="POST" enctype="multipart/form-data" class="border rounded p-4 mb-5 shadow-sm">
        <div class="mb-3">
            <label for="user_id" class="form-label">انتخاب کاربر:</label>
            <select name="user_id" class="form-select" required>
                <option value="">انتخاب کاربر</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="month" class="form-label">ماه:</label>
            <select name="month" class="form-select" required>
                <option value="">انتخاب ماه</option>
                <?php
                $months = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
                foreach ($months as $m) {
                    echo "<option value=\"$m\">$m</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="year" class="form-label">سال:</label>
            <input type="number" name="year" class="form-control" value="<?= jdate('Y') ?>" required>
        </div>

        <div class="mb-3">
            <label for="salary_file" class="form-label">آپلود فیش حقوقی (PDF یا Excel):</label>
            <input type="file" name="salary_file" class="form-control" accept=".pdf, .xls, .xlsx" required>
        </div>

        <button type="submit" class="btn btn-success"><i class="fa fa-upload me-1"></i>آپلود فیش حقوقی</button>
    </form>

    <h4 class="mb-3">📄 لیست فیش‌های حقوقی</h4>
    <?php if (count($salary_slips)): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ردیف</th>
                        <th>نام کاربر</th>
                        <th>ماه</th>
                        <th>سال</th>
                        <th>دانلود</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($salary_slips as $index => $s): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($user_names[$s['user_id']] ?? '---') ?></td>
                            <td><?= $s['month'] ?></td>
                            <td><?= $s['year'] ?></td>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="download_salary.php?file=<?= urlencode($s['file_path']) ?>" target="_blank">
                                    <i class="fa fa-download"></i> دانلود
                                </a>
                            </td>
                            <td>
                                <a href="edit_salary.php?id=<?= $s['id'] ?>" class="btn btn-warning btn-sm me-1">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="delete_salary.php?id=<?= $s['id'] ?>" class="btn btn-danger btn-sm"
                                   onclick="return confirm('آیا از حذف این فیش مطمئن هستید؟')">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info">هنوز فیشی آپلود نشده است.</div>
    <?php endif; ?>
</div>

</body>
</html>
