<?php
session_start();
require_once '../database/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email']; // ایمیل وارد شده
    $password = $_POST['password']; // کد ملی به عنوان رمز عبور

    // چک کردن ایمیل و کد ملی در دیتابیس ادمین
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    // مقایسه کد ملی وارد شده با آنچه در دیتابیس ذخیره شده است
    if ($admin && $password == $admin['password']) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        header("Location: admin_dashboard.php");
        exit;
    } else {
        echo "<p class='text-danger'>ایمیل یا کد ملی اشتباه است.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به پنل ادمین</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="card shadow-lg p-4 w-50">
            <h3 class="text-center mb-4">ورود به پنل ادمین</h3>
            <form action="index.php" method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label">ایمیل</label>
                    <input type="email" name="email" class="form-control" placeholder="ایمیل خود را وارد کنید" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">کد ملی</label>
                    <input type="password" name="password" class="form-control" placeholder="کد ملی خود را وارد کنید" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">ورود به پنل ادمین</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
