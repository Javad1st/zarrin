<?php
session_start();
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$message = '';
$errors = [];

$name = '';
$national_code = '';
$phone = '';
$is_admin = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // گرفتن و فیلتر کردن ورودی‌ها
    $name = trim($_POST['name'] ?? '');
    $national_code = trim($_POST['national_code'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password_raw = $_POST['password'] ?? '';
    $is_admin = isset($_POST['is_admin']) ? (int)$_POST['is_admin'] : 0;

    // اعتبارسنجی‌ها
    if ($name === '') {
        $errors[] = "لطفاً نام و نام خانوادگی را وارد کنید.";
    } elseif (mb_strlen($name) > 100) {
        $errors[] = "طول نام و نام خانوادگی نباید بیش از 100 کاراکتر باشد.";
    }

    if ($national_code === '') {
        $errors[] = "لطفاً کد ملی را وارد کنید.";
    } elseif (!preg_match('/^\d{10}$/', $national_code)) {
        $errors[] = "کد ملی وارد شده معتبر نیست. باید 10 رقم باشد.";
    }

    if ($phone === '') {
        $errors[] = "لطفاً شماره تلفن را وارد کنید.";
    } elseif (!preg_match('/^09\d{9}$/', $phone)) {
        $errors[] = "شماره تلفن باید با 09 شروع شود و 11 رقم باشد.";
    }

    if ($password_raw === '') {
        $errors[] = "لطفاً رمز عبور را وارد کنید.";
    } elseif (strlen($password_raw) < 6) {
        $errors[] = "رمز عبور باید حداقل 6 کاراکتر باشد.";
    }

    if (!in_array($is_admin, [0, 1], true)) {
        $errors[] = "دسترسی ادمین نامعتبر است.";
    }

    if (empty($errors)) {
        try {
            // چک کردن وجود کد ملی
            $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE national_code = :national_code AND is_deleted = 0");
            $stmt->bindValue(':national_code', $national_code, PDO::PARAM_STR);
            $stmt->execute();
            $exists = $stmt->fetchColumn();

            if ($exists) {
                $errors[] = "کد ملی وارد شده تکراری است.";
            } else {
                // هش کردن رمز عبور
                $password = password_hash($password_raw, PASSWORD_DEFAULT);

                // درج اطلاعات
                $stmt = $conn->prepare("INSERT INTO users (name, national_code, phone, password, is_admin, is_deleted)
                                        VALUES (:name, :national_code, :phone, :password, :is_admin, 0)");
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':national_code', $national_code);
                $stmt->bindParam(':phone', $phone);
                $stmt->bindParam(':password', $password);
                $stmt->bindParam(':is_admin', $is_admin, PDO::PARAM_INT);

                if ($stmt->execute()) {
                    $message = "✅ کاربر جدید با موفقیت اضافه شد.";
                    // خالی کردن فرم
                    $name = '';
                    $national_code = '';
                    $phone = '';
                    $is_admin = 0;
                } else {
                    $errors[] = "خطا در ثبت کاربر.";
                }
            }
        } catch (PDOException $e) {
            $errors[] = "خطای پایگاه داده: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>افزودن کاربر جدید</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f1f3f5; font-family: 'Vazirmatn', sans-serif; }
        .container { margin-top: 60px; }
        .card { border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        input[type="password"] { direction: ltr; text-align: left; }
    </style>
</head>
<body>

<div class="container">
    <?php require_once 'sidebar.php'; ?>

    <div class="card p-4 mx-auto" style="max-width: 500px;">
        <h4 class="mb-4 text-center"><i class="fas fa-user-plus me-2"></i>افزودن کاربر جدید</h4>

        <?php if ($message): ?>
            <div class="alert alert-success text-center"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="add_user.php" method="POST" novalidate>
            <div class="mb-3">
                <label for="name" class="form-label"><i class="fas fa-user"></i> نام و نام خانوادگی</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($name); ?>" required>
            </div>

            <div class="mb-3">
                <label for="national_code" class="form-label"><i class="fas fa-id-card"></i> کد ملی</label>
                <input type="text" name="national_code" id="national_code" class="form-control" value="<?php echo htmlspecialchars($national_code); ?>" required>
            </div>

            <div class="mb-3">
                <label for="phone" class="form-label"><i class="fas fa-phone"></i> شماره تلفن</label>
                <input type="text" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($phone); ?>" required>
            </div>

            <div class="mb-3" style="position: relative;">
                <label for="password" class="form-label"><i class="fas fa-lock"></i> رمز عبور</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="********" required>
                <span id="togglePassword" style="position: absolute; top: 38px; right: 10px; cursor: pointer; color: #666;">
                    <i class="fas fa-eye"></i>
                </span>
            </div>

            <script>
                const togglePassword = document.querySelector('#togglePassword');
                const passwordInput = document.querySelector('#password');

                togglePassword.addEventListener('click', function () {
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
                });
            </script>

            <div class="mb-3">
                <label for="is_admin" class="form-label"><i class="fas fa-user-shield"></i> دسترسی ادمین</label>
                <select name="is_admin" id="is_admin" class="form-select">
                    <option value="1" <?php if($is_admin == 1) echo 'selected'; ?>>بله</option>
                    <option value="0" <?php if($is_admin == 0) echo 'selected'; ?>>خیر</option>
                </select>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-primary">افزودن کاربر</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
