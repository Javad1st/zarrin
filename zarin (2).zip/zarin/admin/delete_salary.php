<?php
session_start();
require_once '../database/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // دریافت مسیر فایل برای حذف فیزیکی
    $stmt = $conn->prepare("SELECT file_path FROM salary_slips WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($file) {
        // حذف رکورد
        $stmt = $conn->prepare("DELETE FROM salary_slips WHERE id = :id");
        $stmt->execute(['id' => $id]);

        // حذف فایل از سرور
        if (file_exists($file['file_path'])) {
            unlink($file['file_path']);
        }
    }
}

header("Location: manage_salary_slips.php");
exit;
