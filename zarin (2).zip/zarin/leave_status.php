<?php
session_start();
require_once './database/db.php';
require_once 'jdf.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :user_id AND is_deleted = 0");
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: index.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM leave_requests WHERE user_id = :user_id ORDER BY request_at DESC");
$stmt->execute(['user_id' => $user_id]);
$leaves = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>وضعیت مرخصی</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.fontcdn.ir/Font/Persian/IranSans/IranSans.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'IranSans', sans-serif !important;
            background-color: #f4f7fa;
        }

        .sidebar {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 17px;
            display: block;
        }

        .sidebar a:hover {
            background-color: #007bff;
        }

        .content {
            padding: 30px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: #007bff;
        }

        h2 {
            color: #343a40;
            font-weight: bold;
        }

        .status-pending { color: orange; }
        .status-approved { color: green; }
        .status-rejected { color: red; }

        /* Styling for the leave request cards */
        .leave-request-card {
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
        }

        .leave-request-card h5 {
            font-size: 1.1rem;
            color: #343a40;
            margin-bottom: 10px;
        }

        .leave-request-card .leave-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }

        .leave-request-card .leave-item span {
            color: #6c757d;
        }

        .leave-request-card .leave-item strong {
            color: #343a40;
        }

        /* Status colors */
        .leave-request-card .status-pending {
            color: orange;
        }

        .leave-request-card .status-approved {
            color: green;
        }

        .leave-request-card .status-rejected {
            color: red;
        }

        /* Line between leave requests */
        .leave-request-card + .leave-request-card {
            border-top: 2px solid #ddd;
        }

        /* Responsive adjustment */
        @media (max-width: 768px) {
            .leave-request-card h5 {
                font-size: 1rem;
            }

            .leave-request-card .leave-item span {
                font-size: 0.9rem;
            }
        }

    </style>
</head>
<body>

<div class="dashboard-container">
    <?php require_once 'sidebar.php'; ?>

    <!-- Content -->
    <div class="content container-fluid">
        <h2 class="mb-4">وضعیت مرخصی‌ها - <?= htmlspecialchars($user['name']) ?></h2>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><i class="fa fa-calendar-alt"></i> لیست مرخصی‌ها</h5>

                <?php if (count($leaves)): ?>
                    <div class="mt-3">
                        <?php foreach ($leaves as $leave): ?>
                            <div class="leave-request-card">
                                <h5>جزئیات مرخصی</h5>
                                <div class="leave-item">
                                    <span>از تاریخ</span>
                                    <strong><?= htmlspecialchars($leave['date_from']) ?></strong>
                                </div>
                                <div class="leave-item">
                                    <span>تا تاریخ</span>
                                    <strong><?= htmlspecialchars($leave['date_to']) ?></strong>
                                </div>
                                <div class="leave-item">
                                    <span>از ساعت</span>
                                    <strong><?= htmlspecialchars($leave['time_from']) ?></strong>
                                </div>
                                <div class="leave-item">
                                    <span>تا ساعت</span>
                                    <strong><?= htmlspecialchars($leave['time_to']) ?></strong>
                                </div>
                                <div class="leave-item">
                                    <span>دلیل</span>
                                    <strong><?= htmlspecialchars($leave['reason']) ?></strong>
                                </div>
                                <div class="leave-item">
                                    <span>وضعیت</span>
                                    <strong class="status-<?= $leave['status'] ?>">
                                        <?php
                                        switch ($leave['status']) {
                                            case 'pending':
                                                echo '<span class="status-pending bg-warning text-light p-2 rounded-2">در انتظار تأیید</span>';
                                                break;
                                            case 'approved':
                                                echo '<span class="status-approved bg-success text-light p-2 rounded-2">تأیید شده</span>';
                                                break;
                                            case 'rejected':
                                                echo '<span class="status-rejected bg-danger text-light p-2 rounded-2 ">رد شده</span>';
                                                break;
                                            default:
                                                echo 'نامشخص';
                                        }
                                        ?>
                                    </strong>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted">هیچ مرخصی ثبت نشده است.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>
