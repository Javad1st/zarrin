<?php
// اتصال به دیتابیس
include './database/db.php';

// بررسی اینکه آیا درخواست تایید یا رد شده و هنوز دیده نشده وجود دارد
$sql = "SELECT * FROM leave_requests 
        WHERE user_id = :user_id 
        AND (status = 'approved' OR status = 'rejected') 
        AND seen_by_user = 0";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();

$leave_request = $stmt->fetch(PDO::FETCH_ASSOC);
$show_red_dot = $leave_request ? true : false;

// اگر کاربر وارد صفحه وضعیت مرخصی شده باشد، وضعیت به دیده شده تغییر کند
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['view_leave_status'])) {
    $update_sql = "UPDATE leave_requests 
                   SET seen_by_user = 1 
                   WHERE user_id = :user_id 
                   AND (status = 'approved' OR status = 'rejected')";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $update_stmt->execute();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>داشبورد</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'IranSans', sans-serif !important;
            background-color: #f4f7fa;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
            width: 100%;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 17px;
            display: block;
            position: relative;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #007bff;
        }

        .red-dot {
            position: absolute;
            top: 14px;
            right: 10px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: red;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            display: none;
            z-index: 9999;
        }

        @media (min-width: 768px) {
            .dashboard-container {
                display: flex;
            }

            .sidebar {
                width: 250px;
                height: 100vh;
                position: fixed;
                right: 0;
                top: 0;
            }

            .content {
                margin-right: 260px;
                padding: 30px 15px;
            }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2 class="text-center mb-4">داشبورد</h2>
    <a href="dashboard.php"><i class="fa fa-home"></i> صفحه اصلی</a>
    <a href="request_leave.php"><i class="fa fa-user"></i> درخواست مرخصی </a>
    <a href="leave_status.php?view_leave_status=true">
        <i class="fa-solid fa-clock"></i> وضعیت مرخصی
        <?php if ($show_red_dot): ?>
            <span class="red-dot" id="status-dot"></span>
        <?php endif; ?>
    </a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> خروج</a>
</div>

<?php if ($show_red_dot): ?>
    <div class="notification" id="notification">
        وضعیت مرخصی شما بررسی شده است!
    </div>
<?php endif; ?>

<script>
    <?php if ($show_red_dot): ?>
        var notification = document.getElementById('notification');
        notification.style.display = 'block';
        setTimeout(function () {
            notification.style.display = 'none';
        }, 5000);
    <?php endif; ?>
</script>

</body>
</html>
